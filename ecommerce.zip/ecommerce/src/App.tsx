
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Header from './layout/Header';
import FetchAllProducts from './products/FetchAllProducts';
import Footer from './layout/Footer';

function App() {
  return (
    <Router>
      <Header />
      <Routes>
      <Route path='/' element={<FetchAllProducts />} />
      </Routes>
      <Footer />
    </Router>
  );
}

export default App;
