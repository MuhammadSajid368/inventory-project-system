import { gql } from "@apollo/client";

export const GET_PRODUCTS = gql`
  query {
    products {
      id
      title
      description
      category
      price
      discountPercentage
      rating
      stock
      tags
      brand
      sku
      weight
      dimensions {
        width
        height
        depth
      }
      warrantyInformation
      shippingInformation
      availabilityStatus
      reviews {
        rating
        comment
        date
        reviewerName
        reviewerEmail
      }
      returnPolicy
      minimumOrderQuantity
      meta {
        createdAt
        updatedAt
        barcode
        qrCode
      }
      images
      thumbnail
    }
  }
`;
