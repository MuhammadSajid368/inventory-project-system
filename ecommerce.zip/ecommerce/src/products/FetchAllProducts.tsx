import { useQuery } from "@apollo/client";
import React from "react";
import { GET_PRODUCTS } from "../queries";

interface Product {
  id: string;
  title: string;
  price: number;
  description: string;
  discountPercentage: number;
  rating: number;
  stock: number;
  thumbnail: string;
}

interface ProductsData {
  products: Product[];
}

const FetchAllProducts: React.FC = () => {
  const { loading, error, data } = useQuery<ProductsData>(GET_PRODUCTS);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  return (
    <div className="p-4 bg-gray-100 min-h-screen pt-24">
      <h1 className="text-2xl font-bold mb-6 text-center text-gray-800">All Products</h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {data?.products.map((product) => (
          <div
            key={product.id}
            className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200 overflow-hidden flex flex-col"
          >
            <a href="#">
              <img
                className="w-full h-48 object-cover"
                src={product.thumbnail || "https://via.placeholder.com/150"}
                alt={product.title}
              />
            </a>
            <div className="p-4 flex flex-col flex-grow">
              <a href="#">
                <h5 className="text-base font-semibold tracking-tight text-gray-800 hover:text-blue-600 transition-colors truncate">
                  {product.title}
                </h5>
              </a>
              <p className="text-xs text-gray-500 mt-1 line-clamp-2">
                {product.description}
              </p>

              <div className="flex items-center justify-between mt-2">
                <p className="text-lg font-bold text-gray-900">${product.price.toFixed(2)}</p>
                <span className="text-xs font-semibold text-red-600 bg-red-100 rounded-full px-2 py-1">
                  {product.discountPercentage}% Off
                </span>
              </div>

              <div className="flex items-center justify-between text-xs text-gray-600 mt-2">
                <span className="flex items-center">
                  Rating: {product.rating}
                
                </span>
                <span
                  className={`font-medium ${
                    product.stock > 0 ? "text-green-600" : "text-red-600"
                  }`}
                >
                  {product.stock > 0 ? "In Stock" : "Out of stock"}
                </span>
              </div>

              <a
                href="#"
                className="mt-3 inline-flex items-center justify-center px-3 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                View Details
                <svg
                  className="w-4 h-4 ml-2"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 14 10"
                >
                  <path
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M1 5h12m0 0L9 1m4 4L9 9"
                  />
                </svg>
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FetchAllProducts;
