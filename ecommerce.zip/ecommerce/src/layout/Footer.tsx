import React from "react";

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-white pt-10 pb-8">
      <div className="container mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8 px-4">
        {/* Company Information */}
        <div>
          <h3 className="text-lg font-semibold mb-4">About Us</h3>
          <p className="text-gray-400 text-sm leading-relaxed">
            We are committed to providing the best products and services in the
            industry. Our passion for excellence drives us to bring you
            top-quality goods with a seamless shopping experience.
          </p>
        </div>

        {/* Quick Links */}
        <div>
          <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
          <ul>
            <li className="mb-2">
              <a href="#" className="text-gray-400 hover:text-gray-200 text-sm">
                Home
              </a>
            </li>
            <li className="mb-2">
              <a href="#" className="text-gray-400 hover:text-gray-200 text-sm">
                Shop
              </a>
            </li>
            <li className="mb-2">
              <a href="#" className="text-gray-400 hover:text-gray-200 text-sm">
                About Us
              </a>
            </li>
            <li className="mb-2">
              <a href="#" className="text-gray-400 hover:text-gray-200 text-sm">
                Contact
              </a>
            </li>
          </ul>
        </div>

        {/* Contact Information */}
        <div>
          <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
          <ul>
            <li className="text-gray-400 text-sm mb-2">
              <i className="fas fa-phone-alt"></i> +1 (123) 456-7890
            </li>
            <li className="text-gray-400 text-sm mb-2">
              <i className="fas fa-envelope"></i> info@shop.com
            </li>
            <li className="text-gray-400 text-sm mb-2">
              <i className="fas fa-map-marker-alt"></i> 123 E-commerce St, NY,
              USA
            </li>
          </ul>
        </div>

        {/* Newsletter Subscription */}
        <div>
          <h3 className="text-lg font-semibold mb-4">Subscribe</h3>
          <p className="text-gray-400 text-sm mb-4">
            Join our newsletter to get updates on our latest products and
            offers.
          </p>
          <form>
            <div className="flex items-center">
              <input
                type="email"
                className="w-full px-3 py-2 rounded-l-lg text-gray-800 focus:outline-none"
                placeholder="Enter your email"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-r-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300"
              >
                Subscribe
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Social Links */}
      <div className="border-t border-gray-700 mt-8 pt-8">
        <div className="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center text-gray-400">
          <p className="text-sm mb-4 md:mb-0">
            &copy; 2024 Shopping Site. All rights reserved.
          </p>
          <div className="flex space-x-4">
            <a href="#" className="hover:text-white">
              <i className="fab fa-facebook-f"></i>
            </a>
            <a href="#" className="hover:text-white">
              <i className="fab fa-twitter"></i>
            </a>
            <a href="#" className="hover:text-white">
              <i className="fab fa-instagram"></i>
            </a>
            <a href="#" className="hover:text-white">
              <i className="fab fa-linkedin-in"></i>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
