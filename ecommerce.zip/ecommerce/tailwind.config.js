/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,tsx,jsx,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
}