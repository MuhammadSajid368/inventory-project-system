const { ApolloServer, gql } = require("apollo-server");
const axios = require("axios");
const  { typeDefs } = require('./types')


const resolvers = {
  Query: {
    products: async () => {
      try {
        const response = await axios.get("https://dummyjson.com/products");
        return response.data.products.map(
          ({
            id,
            title,
            description,
            category,
            price,
            discountPercentage,
            rating,
            stock,
            tags,
            brand,
            sku,
            weight,
            dimensions,
            warrantyInformation,
            shippingInformation,
            availabilityStatus,
            reviews,
            returnPolicy,
            minimumOrderQuantity,
            meta,
            images,
            thumbnail,
          }) => ({
            id,
            title,
            description,
            category,
            price,
            discountPercentage,
            rating,
            stock,
            tags,
            brand,
            sku,
            weight,
            dimensions,
            warrantyInformation,
            shippingInformation,
            availabilityStatus,
            reviews,
            returnPolicy,
            minimumOrderQuantity,
            meta,
            images,
            thumbnail,
          })
        );
      } catch (error) {
        throw error;
      }
    },
  },
};

const server = new ApolloServer({
  typeDefs,
  resolvers,
});

server.listen().then(({ url }) => console.log(`Server ready at ${url}`));
